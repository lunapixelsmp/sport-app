package com.example.sport;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.sport.adapters.WorkoutCategoryAdapter;
import com.example.sport.models.UserLevel;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private UserLevel currentUserLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkUserLevel();
        setupWorkoutCategories();
        setupChangeLevelButton();
    }

    private void checkUserLevel() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String level = prefs.getString("user_level", null);

        if (level == null) {
            startActivity(new Intent(this, UserLevelSelectionActivity.class));
            finish();
        } else {
            currentUserLevel = UserLevel.fromString(level);
        }
    }

    private void setupWorkoutCategories() {
        List<String> categories = Arrays.asList("Руки", "Грудь", "Пресс", "Ноги", "Комплексная");

        RecyclerView recyclerView = findViewById(R.id.categoriesRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        WorkoutCategoryAdapter adapter = new WorkoutCategoryAdapter(categories, category -> {
            Intent intent = new Intent(MainActivity.this, WorkoutActivity.class);
            intent.putExtra("category", category);
            intent.putExtra("user_level", currentUserLevel.name());
            startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
    }

    private void setupChangeLevelButton() {
        findViewById(R.id.changeLevelBtn).setOnClickListener(v -> {
            startActivity(new Intent(this, UserLevelSelectionActivity.class));
            finish();
        });
    }
}