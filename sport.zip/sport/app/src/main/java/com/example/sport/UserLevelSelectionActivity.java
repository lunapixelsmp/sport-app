package com.example.sport;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sport.models.UserLevel;

public class UserLevelSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_level_selection);

        Button beginnerBtn = findViewById(R.id.beginnerBtn);
        Button intermediateBtn = findViewById(R.id.intermediateBtn);
        Button advancedBtn = findViewById(R.id.advancedBtn);

        beginnerBtn.setOnClickListener(v -> setUserLevel(UserLevel.BEGINNER));
        intermediateBtn.setOnClickListener(v -> setUserLevel(UserLevel.INTERMEDIATE));
        advancedBtn.setOnClickListener(v -> setUserLevel(UserLevel.ADVANCED));
    }

    private void setUserLevel(UserLevel level) {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        prefs.edit().putString("user_level", level.name()).apply();

        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}