package com.example.sport.models;

import java.io.Serializable;

public class Exercise implements Serializable {
    private int id;
    private String name;
    private String description;
    private int baseReps;
    private int baseDuration;
    private String bodyPart;
    private int imageResId;

    public Exercise(int id, String name, String description, int baseReps,
                    int baseDuration, String bodyPart, int imageResId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.baseReps = baseReps;
        this.baseDuration = baseDuration;
        this.bodyPart = bodyPart;
        this.imageResId = imageResId;
    }

    public int getAdjustedReps(float multiplier) {
        return (int) (baseReps * multiplier);
    }

    public int getAdjustedDuration(float multiplier) {
        return (int) (baseDuration * multiplier);
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getBaseReps() {
        return baseReps;
    }

    public int getBaseDuration() {
        return baseDuration;
    }

    public String getBodyPart() {
        return bodyPart;
    }

    public int getImageResId() {
        return imageResId;
    }
}