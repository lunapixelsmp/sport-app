package com.example.sport.models;

public enum UserLevel {
    BEGINNER(1.0f),
    INTERMEDIATE(1.5f),
    ADVANCED(2.0f);

    private final float multiplier;

    UserLevel(float multiplier) {
        this.multiplier = multiplier;
    }

    public float getMultiplier() {
        return multiplier;
    }

    public static UserLevel fromString(String level) {
        try {
            return valueOf(level);
        } catch (Exception e) {
            return BEGINNER;
        }
    }
}