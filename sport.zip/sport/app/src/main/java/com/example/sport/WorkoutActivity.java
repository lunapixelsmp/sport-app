package com.example.sport;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sport.models.Exercise;
import com.example.sport.models.UserLevel;
import java.util.ArrayList;
import java.util.List;

public class WorkoutActivity extends AppCompatActivity {

    private List<Exercise> exercises = new ArrayList<>();
    private UserLevel userLevel;
    private int currentExerciseIndex = 0;
    private CountDownTimer timer;

    private TextView exerciseName, exerciseReps, timerText;
    private ImageView exerciseImage;
    private ProgressBar progressBar;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        // Инициализация views
        exerciseName = findViewById(R.id.exerciseName);
        exerciseReps = findViewById(R.id.exerciseReps);
        timerText = findViewById(R.id.timerText);
        exerciseImage = findViewById(R.id.exerciseImage);
        progressBar = findViewById(R.id.progressBar);
        nextButton = findViewById(R.id.nextButton);

        // Получаем данные из Intent
        String category = getIntent().getStringExtra("category");
        String level = getIntent().getStringExtra("user_level");

        if (level != null) {
            userLevel = UserLevel.fromString(level);
            loadExercises(category);
            startCurrentExercise();
        } else {
            finish(); // Закрываем если нет данных
        }

        nextButton.setOnClickListener(v -> {
            if (timer != null) timer.cancel();
            moveToNextExercise();
        });
    }

    private void loadExercises(String category) {
        exercises.clear();

        if ("Руки".equals(category)) {
            exercises.add(new Exercise(1, "Отжимания узким хватом", "3 подхода", 15, 0, "Руки", R.drawable.pullup));
            exercises.add(new Exercise(2, "Обратные отжимания от скамьи/стула", "3 подхода", 10, 0, "Руки", R.drawable.pullup));
            exercises.add(new Exercise(3, "Планка с касанием плеч", "3 подхода", 0, 0, "Руки", R.drawable.pullup));
            exercises.add(new Exercise(4, "Подъем рук с гантелями в стороны", "3 подхода", 10, 0, "Руки", R.drawable.pullup));
            exercises.add(new Exercise(5, "\"Молоток\" с гантелями", "3 подхода", 10, 0, "Руки", R.drawable.pullup));
        }
        else if ("Грудь".equals(category)) {
            exercises.add(new Exercise(6, "Классические отжимания", "4 подхода", 15, 0, "Грудь", R.drawable.pullup));
            exercises.add(new Exercise(7, "Отжимания с широкой постановкой рук", "3 подхода", 10, 0, "Грудь", R.drawable.pullup));
            exercises.add(new Exercise(8, "Отжимания с ногами на возвышенности", "3 подхода", 10, 0, "Грудь", R.drawable.pullup));
            exercises.add(new Exercise(9, "Плиометрические отжимания (с хлопком)", "3 подхода", 8, 0, "Грудь", R.drawable.pullup));
            exercises.add(new Exercise(10, "Изометрия — удержание в нижнем положении отжиманий", "3 подхода", 0, 0, "Грудь", R.drawable.pullup));
        }

        else if ("Пресс".equals(category)) {
            exercises.add(new Exercise(11, "Классические скручивания", "3 подхода", 20, 0, "Пресс", R.drawable.pullup));
            exercises.add(new Exercise(12, "Подъемы ног лежа", "3 подхода", 15, 0, "Пресс", R.drawable.pullup));
            exercises.add(new Exercise(13, "Велосипед ", "3 подхода", 0, 0, "Пресс", R.drawable.pullup));
            exercises.add(new Exercise(14, "Планка на локтях", "3 подхода", 0, 0, "Пресс", R.drawable.pullup));
            exercises.add(new Exercise(15, "Планка с подтягиванием коленей к груди (горка)", "3 подхода", 12, 0, "Пресс", R.drawable.pullup));
        }
    }

    private void startCurrentExercise() {
        if (currentExerciseIndex >= exercises.size()) {
            finishWorkout();
            return;
        }

        Exercise current = exercises.get(currentExerciseIndex);
        displayExercise(current);
        startTimer(current);
    }

    private void displayExercise(Exercise exercise) {
        exerciseName.setText(exercise.getName());
        exerciseReps.setText("Повторов: " + exercise.getAdjustedReps(userLevel.getMultiplier()));
        exerciseImage.setImageResource(exercise.getImageResId());
    }

    private void startTimer(Exercise exercise) {
        int duration = exercise.getAdjustedDuration(userLevel.getMultiplier());
        progressBar.setMax(duration);
        progressBar.setProgress(duration);
        nextButton.setEnabled(false);

        timer = new CountDownTimer(duration * 1000L, 1000) {
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                timerText.setText(String.format("%02d:%02d", seconds / 60, seconds % 60));
                progressBar.setProgress(seconds);
            }

            public void onFinish() {
                timerText.setText("00:00");
                progressBar.setProgress(0);
                nextButton.setEnabled(true);
            }
        }.start();
    }

    private void moveToNextExercise() {
        currentExerciseIndex++;
        startCurrentExercise();
    }

    private void finishWorkout() {
        finish(); // Возвращаемся на предыдущий экран
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }
}